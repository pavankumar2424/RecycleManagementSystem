package com.cognizant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class RecycleManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
